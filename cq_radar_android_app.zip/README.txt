CQ RADAR — Android installable web app

Includes the official BOM Gladstone (IDR233) and Emerald (IDR722) radar loop pages, phone-stacked layout, side-by-side toggle, refresh and full-screen controls.

IMPORTANT: This is a Progressive Web App (PWA), not a Play Store APK. Android requires it to be hosted on a secure HTTPS website before Chrome offers Install app. BOM may restrict its pages from appearing inside another page; if a panel is blank, tap its Open BOM link to see the official feed.

INSTALL ON SAMSUNG:
1. Publish all files in this folder to an HTTPS static website (for example GitHub Pages or Netlify).
2. Open that HTTPS address in Chrome on your Samsung.
3. Open Chrome menu (⋮), choose Install app or Add to Home screen.
4. Launch CQ Radar from your home screen.

Internet is required for live radar. The app shell can be cached, but radar data is not available offline.
